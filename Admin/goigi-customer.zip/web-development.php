<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Web Development</h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item active">Web Development</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
         <!-- end row -->
         <div class="row">
            <div class="col-xl-12">
               <div class="card custom-shadow rounded-lg border">
                  <div class="card-body">
                     <h4 class="card-title mb-4">Project List</h4>
                     <div>
                       <table id="datatable" class="table table-bordered dt-responsive nowrap">
                           <thead class="thead-light">
                              <tr>
                                 <th width="70px">Project ID</th>
                                 <th>Project Name</th>
                                 <th width="70">Start Date</th>
                                 <th width="30">$ Total</th>
                                 <th width="30">$ Due</th>
                                 <th width="70px">Status</th>
                                 <th width="80">Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td>IGI4500</td>
                                 <td>(ID: IGI1244) Demo Project Ecommerce Web Development  </td>
                                 <td>10-08-2022</td>
                                 <td>$6000</td>
                                 <td>$10000</td>
                                 <td><span class="badge rounded-pill badge-soft-primary font-size-12 custom-shadow">In progress</span></td>
                                 <td><a href="project-details.php" class="btn btn-outline-primary btn-sm">View Details</a></td>
                              </tr>
                              <tr>
                                 <td>IGI4500</td>
                                 <td>Esycles</td>
                                 <td>10-08-2022</td>
                                 <td>$6000</td>
                                 <td>$1000</td>
                                 <td><span class="badge rounded-pill badge-primary font-size-12 custom-shadow">Completed</span></td>
                                 <td><a href="project-details.php" class="btn btn-outline-primary btn-sm">View Details</a></td>
                              </tr>
                              <tr>
                                 <td>IGI4500</td>
                                 <td>Esycles</td>
                                 <td>10-08-2022</td>
                                 <td>$6000</td>
                                 <td>$1000</td>
                                 <td><span class="badge rounded-pill badge-soft-primary font-size-12 custom-shadow">In progress</span></td>
                                 <td><a href="project-details.php" class="btn btn-outline-primary btn-sm">View Details</a></td>
                              </tr>

                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   
<?php include('footer.php'); ?>
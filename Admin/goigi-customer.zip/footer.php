    <footer class="footer">
          <div class="container-fluid">
             <div class="row">
                <div class="col-sm-12">
                   <div class="text-sm-end d-sm-block">
                      &copy; 2022 Goigi. All Rights Reserved.
                   </div>
                </div>
             </div>
          </div>
       </footer>
    </div>
</div>
<!-- END layout-wrapper -->

<!-- Modal -->
<div class="modal fade" id="lastloginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="lastloginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content rounded-0 border-primary">
      <div class="modal-header py-2 bg-primary rounded-0">
        <h5 class="modal-title text-white" id="staticBackdropLabel">Last Login Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Device IP</th>
               </tr>
            </thead>
           <tbody>
              <tr>
                 <td>12-08-2022</td>
                 <td>10:55 am</td>
                 <td>121.125.125.522</td>
              </tr>
              <tr>
                 <td>12-08-2022</td>
                 <td>10:55 am</td>
                 <td>121.125.125.522</td>
              </tr>
              <tr>
                 <td>12-08-2022</td>
                 <td>10:55 am</td>
                 <td>121.125.125.522</td>
              </tr>
              
           </tbody>
        </table>
      </div>
   </div>
  </div>
</div>

<!-- /Right-bar -->
<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>
<!-- JAVASCRIPT -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/libs/apexcharts/apexcharts.min.js"></script>
<script src="assets/libs/admin-resources/jquery.vectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="assets/libs/admin-resources/jquery.vectormap/maps/jquery-jvectormap-us-merc-en.js"></script>
<script src="assets/js/pages/dashboard.init.js"></script>
<!-- Required datatable js -->
<script src="assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="assets/libs/jszip/jszip.min.js"></script>
<script src="assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="assets/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="assets/libs/datatables.net-select/js/dataTables.select.min.js"></script>
<!-- Responsive examples -->
<script src="assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<script src="assets/js/pages/datatables.init.js"></script>
<script src="assets/js/app.js"></script>
<script type="text/javascript">
   function readprofile(input) {
       if (input.files && input.files[0]) {
           var reader = new FileReader();

           reader.onload = function (e) {
               $('#profileIMG')
                   .attr('src', e.target.result);
           };

           reader.readAsDataURL(input.files[0]);
       }
   }
</script>
</body>
</html>
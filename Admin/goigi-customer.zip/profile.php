<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Profile</h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item active">Profile</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
 
         <div class="card custom-shadow rounded-lg border">
         	<div class="card-body">
               <form>
                  <div class="row">
                     <div class="col-lg-2">
                        <figure class="group-dp">
                           <img id="profileIMG" src="assets/images/user-icon.jpg" alt="">
                           <label class="uploadprofileImg custom-shadow">
                              <i class="fas fa-camera"></i> 
                              <input type='file' onchange="readprofile(this);" />
                           </label>
                        </figure>
                     </div>
                     <div class="col-lg-10">
                        
                        <h5 class="h6 text-secondary mb-2">Client ID: <span class="text-primary">CI14545</span></h5>
                        
                        <div class="mt-3">
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">First Name:</label>
                                 <div class="col-lg-6">
                                    <input type="text" value="John" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">Last Name:</label>
                                 <div class="col-lg-6">
                                    <input type="text" value="Doe" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">Email ID:</label>
                                 <div class="col-lg-6">
                                    <input type="email" value="johndoe22@gmail.com" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">Contact Number:</label>
                                 <div class="col-lg-6">
                                    <input type="text" value="1216454845" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row">
                                 <div class="col-lg-6 offset-lg-3">
                                    <button class="btn btn-primary custom-shadow">Update Profile</button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </form>
               <form>
                  <div class="row">
                     <div class="col-lg-10 offset-lg-2">
                        <div class="mt-4">
                           <h3 class="h5 mb-3 text-uppercase fw-bold">Change Password</h3>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">Current Password:</label>
                                 <div class="col-lg-6">
                                    <input type="password" value="" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">New Password:</label>
                                 <div class="col-lg-6">
                                    <input type="password" value="" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row align-items-center">
                                 <label class="col-lg-3 fw-bold font-size-13">Confirm Password:</label>
                                 <div class="col-lg-6">
                                    <input type="password" value="" class="form-control font-size-13 custom-shadow" name="">
                                 </div>
                              </div>
                           </div>
                           <div class="form-group mb-3">
                              <div class="row">
                                 <div class="col-lg-6 offset-lg-3">
                                    <button class="btn btn-primary custom-shadow">Change Password</button>
                                 </div>
                              </div>
                           </div>
                        </div> 
                     </div>
                  </div>
                  
               </form>   
            </div>
         </div>
      </div>
   </div>
</div>

<?php include('footer.php'); ?>
<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Web Development</h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item active">Web Development</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
 
         <div class="card custom-shadow rounded-lg border">
         	<div class="card-body">
         		<div class="row">
         			<div class="col-lg-8 mb-3">
         				<h2 class="fs-4 mb-1">(ID: IGI1244) Demo Project Ecommerce Web Development </h2>
         				<p class="mb-2">Assignment Date: <span class="fw-bold">01-08-2022</span></p>
                        <p class="mb-2">Estimated Completion Date: <span class="fw-bold">5 Months</span></p>
         				<p class="mb-2">Status: <span class="badge rounded-pill badge-soft-primary font-size-12">In progress</span></p>
         				<p>Technology Uses: <span class="badge rounded-pill bg-primary">HTML, CSS, PHP, Jquery, SQL</span></p>
         				<h6 class="h5 text-primary">Project Description:</h6>
         				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
         				<p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
         				<div class="d-flex mb-3">
                        <a href="#" class="btn btn-primary flex-fill mx-1 shadow-lg">S.O.W. <i class="fas fa-download"></i></a>
                        <a href="workorder-list.php" class="btn btn-primary flex-fill mx-1 shadow-lg">Work Order <i class="fas fa-download"></i></a>
                        <a href="invoice-list.php" class="btn btn-primary flex-fill mx-1 shadow-lg">Invoice <i class="fas fa-download"></i></a>
                     </div>
                     <div class="mb-3">
                        <h4 class="card-title">Project Updates</h4>
                        <div class="row">
                           <div class="col-lg-8 mb-2">
                              <input type="text" class="form-control" readonly name="" value="https://project.com/">
                           </div>
                           <div class="col-lg-4">
                              <a href="project-update.php" class="btn btn-primary w-100 shadow-lg">View Details</a>
                           </div>
                        </div>   
                        
                     </div>
                     <h4 class="card-title">Project Completion status</h4>
		                <div class="mt-3">
                           
		                    <div class="progress">
		                       <div class="progress-bar  progress-bar-striped progress-bar-animated" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>
		                    </div>
                          <div class="d-flex justify-content-center">
                              <div class="stepcompt flex-fill"><span><a href="" data-bs-toggle="modal" data-bs-target="#completionmodal1" class="text-white">Stage 1</a></span></div>
                              <div class="stepcompt flex-fill"><span><a href="" data-bs-toggle="modal" data-bs-target="#completionmodal1" class="text-white">Stage 2</a></span></div>
                              <div class="stepcompt flex-fill"><span><a href="" data-bs-toggle="modal" data-bs-target="#completionmodal1" class="text-white">Stage 3</a></span></div>
                              <div class="stepcompt flex-fill"><span><a href="" data-bs-toggle="modal" data-bs-target="#completionmodal1" class="text-white">Stage 4</a></span></div>
                           </div>
		                </div>
         			</div>
         			<div class="col-lg-4 mb-3">
         				  <div class="card congo-widget bg-primary text-white-50 custom-shadow rounded-lg border">
	                        <div class="card-body">
	                            <h5 class="mb-1 text-white">Project Cost: </h5>
	                            <h3 class="fs-2 fw-bolder mb-0 text-white">$6000</h3>
                               <h5 class="text-white fs-6 mb-0">Amount Due: $2000</h5>
	                        </div>
	                    </div>
	                    <div class="card border border-primary mb-lg-0 bg-white custom-shadow rounded-lg border">
	                    	<div class="card-body">
	                    		 <h5 class="mb-1">Payment Installment</h5>
	                    		<div data-simplebar style="max-height:200px">
                              <ol class="activity-feed mb-0 ps-3 mt-4 pt-2 pb-0">
                                  <li class="feed-item">
                                      <div class="feed-item-list">
                                          <p class="text-muted mb-1">1st Installment <a href="invoice-details.php" class="ms-2 btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a></p>
                                          <p class="mt-0 mb-0">$1000 <span class="text-primary d-block">Date: 10-08-2022</span></p>
                                      </div>
                                  </li>
                                  <li class="feed-item">
                                      <p class="text-muted mb-1">2nd Installment <a href="invoice-details.php" class="ms-2 btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a></p>
                                      <p class="mt-0 mb-0">$2000 <span class="text-primary d-block">Date: 10-08-2022</span></p>
                                  </li>
                                  <li class="feed-item">
                                      <p class="text-muted mb-1">3rd Installment <a href="invoice-details.php" class="ms-2 btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a></p>
                                      <p class="mt-0 mb-0">$2000 <span class="text-primary d-block">Date: 10-08-2022</span></p>
                                  </li>
                                  <li class="feed-item">
                                      <p class="text-muted mb-1">4th Installment <a href="invoice-details.php" class="ms-2 btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a></p>
                                      <p class="mt-0 mb-0">$2000 <span class="text-primary d-block">Date: 10-08-2022</span></p>
                                  </li>
                              </ol>
                          </div>
	                    	</div>
	                    </div>
	                    <div class="my-4 custom-shadow border"><a href="#" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#raiseticketmodal">Raise a Ticket</a></div>
                       <div class="card border border-primary mb-lg-0 bg-white custom-shadow rounded-lg border">
                        <div class="card-body">
                           <div class="d-flex justify-content-between">
                              <h5 class="mb-1">Maintanance Plan </h5>
                              <div><span class="badge rounded-pill badge-primary font-size-12">Active</span></div>
                           </div>
                           <p class="mb-0">Valid till: 12-12-2022</p>
                           <div class="mt-2"><a href="#" class="btn btn-primary btn-sm shadow">View Details</a></div>
                        </div>
                     </div>
         			</div>
         		</div>
         	</div>
         </div>
         
     </div>
 </div>

<!-- Modal -->
<div class="modal fade" id="raiseticketmodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="raiseticketmodalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-0 modal-border">
      <div class="modal-header">
        <h5 class="modal-title text-uppercase fw-bold" id="staticBackdropLabel">Raise a Ticket</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
            <div class="form-group mb-2">
               <label class="mb-0 font-size-13">Task Title</label>
               <input type="text" class="form-control" name="">
           </div>
           <div class="form-group mb-2">
               <label class="mb-0 font-size-13">Task Description</label>
               <textarea class="form-control"></textarea>
           </div>
           <div class="form-group mb-2">
               <label class="mb-0 font-size-13">Allocate time</label>
               <input type="text" class="form-control " name="">
           </div>
           <div class="form-group text-end mt-3">
               <button type="button" class="btn btn-primary custom-shadow w-100">Ticket Raise</button>
           </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="completionmodal1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="completionmodal1Label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-0 modal-border">
      <div class="modal-header">
        <h5 class="modal-title text-uppercase fw-bold" id="staticBackdropLabel">Completion Status (Stage 1)</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <ol class="activity-feed mb-0 ps-2">
            <li class="feed-item">
              <div class="feed-item-list">
                  <p class="text-muted mb-1">UI Mockup Design</p>
                  <p class="mt-0 mb-0"> <span class="text-primary d-block font-size-13">Update: 10-08-2022</span></p>
              </div>
            </li>
            <li class="feed-item">
              <div class="feed-item-list">
                  <p class="text-muted mb-1">HTML Design</p>
                  <p class="mt-0 mb-0"> <span class="text-primary d-block font-size-13">Update: 20-08-2022</span></p>
              </div>
            </li>
            <li class="feed-item">
              <div class="feed-item-list">
                  <p class="text-muted mb-1">Database Creation</p>
                  <p class="mt-0 mb-0"> <span class="text-primary d-block font-size-13">Update: 22-08-2022</span></p>
              </div>
            </li>
        </ol>
      </div>
    </div>
  </div>
</div>  

<?php include('footer.php'); ?>
<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Invoice </h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item active">Invoice</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
 
         <div class="card custom-shadow rounded-lg border">
         	<div class="card-body">
         		<div class="row">
         			<div class="col-lg-12 mb-3">
         				<h2 class="fs-4 mb-1">Invoice List </h2>
         			</div>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Sl.</th>
                                <th>Date</th>
                                <th>Invoice ID</th>
                                <th>Amount</th>
                                <th>Payment Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </tbody>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>20-08-2022</td>
                                <td>GOII44545</td>
                                <td>$1200</td>
                                <td>20-08-2022</td>
                                <td><span class="badge rounded-pill badge-primary font-size-12">Payment Done</span></td>
                                <td>
                                    <a href="#" class="btn btn-primary btn-xs"><i class="fas fa-download"></i></a>
                                    <a href="invoice-details.php" class="btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>20-08-2022</td>
                                <td>GOII44545</td>
                                <td>$1200</td>
                                <td></td>
                                <td><span class="badge rounded-pill badge-soft-primary font-size-12">Payment Pending</span></td>
                                <td>
                                    <a href="#" class="btn btn-primary btn-xs"><i class="fas fa-download"></i></a>
                                    <a href="invoice-details.php" class="btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>20-08-2022</td>
                                <td>GOII44545</td>
                                <td>$1200</td>
                                <td></td>
                                <td><span class="badge rounded-pill badge-soft-primary font-size-12">Payment Pending</span></td>
                                <td>
                                    <a href="#" class="btn btn-primary btn-xs"><i class="fas fa-download"></i></a>
                                    <a href="invoice-details.php" class="btn btn-outline-primary btn-xs"><i class="far fa-eye"></i></a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
         		</div>
         	</div>
         </div>
         
     </div>
 </div>


<?php include('footer.php'); ?>
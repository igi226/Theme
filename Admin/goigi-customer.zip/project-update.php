<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Project Update</h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item"><a href="web-development.php">Web Development</a></li>
                        <li class="breadcrumb-item active">Project Update</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
 
         <div class="card custom-shadow rounded-lg border">
         	<div class="card-body">
               <h2 class="fs-4 mb-1">(ID: IGI1244) Demo Project Ecommerce Web Development </h2>
               <p class="mb-2">Assignment Date: <span class="fw-bold">01-08-2022</span></p>
               <p class="mb-2">Status: <span class="badge rounded-pill badge-soft-primary font-size-12">In progress</span></p>

               <div class="projectinfo mt-3">
                  <h6>Project Link:</h6>
                  <p><a href="#">https://project.com/demo.com</a></p>
               </div>
               <div class="projectinfo mt-3">
                  <h6>Admin Credential:</h6>
                  <p><a href="#">https://project.com/demo.com/admin</a></p>
                  <div class="row">
                     <div class="col-lg-5">
                        <table class="table table-bordered">
                           <tbody>
                              <tr>
                                 <td class="fw-bold">Login ID:</td>
                                 <td>admin@gmail.com</td>
                              </tr>
                              <tr>
                                 <td class="fw-bold">Password:</td>
                                 <td>#15451Gvhsy</td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="projectinfo mt-3">
                  <h6>Work Module:</h6>
                  <table class="table table-bordered">
                     <thead>
                        <tr>
                           <th width="100">Assign Date</th>
                           <th>Module Task</th>
                           <th>Time</th>
                           <th>Status</th>
                           <th width="100">Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td class="fw-bold font-size-12">12-08-2022</td>
                           <td>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </td>
                           <td>5 hr</td>
                           <td><span class="badge rounded-pill badge-soft-primary font-size-12 custom-shadow">Pending</span></td>
                           <td>
                              <a href="#" class="btn btn-primary btn-xs"><i class="far fa-eye"></i></a>
                              <a href="#" class="btn btn-outline-primary btn-xs"><i class="fas fa-pen"></i></a>
                           </td>
                        </tr>
                        <tr>
                           <td class="fw-bold font-size-12">12-08-2022</td>
                           <td>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. </td>
                           <td>5 hr</td>
                           <td><span class="badge rounded-pill badge-primary font-size-12 custom-shadow">Completed</span></td>
                           <td>
                              <a href="#" class="btn btn-primary btn-xs"><i class="far fa-eye"></i></a>
                              <a href="#" class="btn btn-outline-primary btn-xs"><i class="fas fa-pen"></i></a>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php include('footer.php'); ?>
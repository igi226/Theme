<?php include('header.php'); ?>

<div class="main-content">
   <div class="page-content">
      <div class="container-fluid">
         <!-- start page title -->
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-flex align-items-center justify-content-between">
                  <h4 class="mb-0">Invoice </h4>
                  <div class="page-title-right">
                     <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Home</a></li>
                        <li class="breadcrumb-item active">Invoice</li>
                     </ol>
                  </div>
               </div>
            </div>
         </div>
 
         <div class="card custom-shadow rounded-lg border">
         	<div class="card-body">
                <h3 style="text-align:center; font-size:20px; font-weight:bold; text-transform: uppercase; background: #f0f0f0;
    line-height: 30px;  color: #000; margin-bottom: 20px;">Work Order</h3>
         		<table border="0" width="100%" style="font-size:13px;color: #000;">
                    <thead>
                        <tr>
                            <th><img src="assets/images/goigi-logo.png" width="140"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <table  border="0" width="100%" style="font-size:13px;margin-top: 20px;">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <p style="font-weight:600; margin-bottom: 8px;">Company Info</p>
                                                <p style="margin-bottom:0;">IGLOBAL IMPACT ITES PVT. LTD. <br>
                                                    Webel IT Park, E & G Module<br>
                                                    Palashdiha, Durgapur, West Bengal, India <br>
                                                    <span style="font-weight: 600;">P:</span> IN- +91-9832145050 | US- +1-3475353666 <br>
                                                    UK- +44-2081234676 | AUS- +61(03)90056702 <br>
                                                    <span style="font-weight: 600;">E:</span> info@goigi.com
                                                </p>
                                            </td>
                                            <td style="text-align:right;">
                                                <p>
                                                    <span style="font-weight:600; margin-bottom: 0px;">W.O.ID: </span> #DF1515151 <br>
                                                    <span style="font-weight:600; margin-bottom: 4px;">W.O.Date: </span> 25/08/2022 
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table  border="0" width="100%" style="font-size:13px;margin-top: 20px;">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <p style="font-weight:600; margin-bottom: 8px;">Job Info:</p>
                                                <p>
                                                    Website Development
                                                </p>
                                            </td>
                                            <td style="text-align:right;">
                                                <p style="font-weight:600; margin-bottom: 8px;">Customer Info</p>
                                                <p style="margin-bottom:0;">Leo James More <br>
                                                    Project Name <br>
                                                    18040 NW 19th Avenue, Miami, FL, 33306, USA<br>
                                                    <span style="font-weight: 600;">E:</span> leojames@gmail.com<br>
                                                    <span style="font-weight: 600;">P:</span> 30511551515
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table  border="1" width="100%" style="font-size:13px; margin: 15px 0;">
                                    <thead  style="border:1px solid #ccc;">
                                        <tr>
                                            <th style="padding:5px;">#</th>
                                            <th style="padding:5px;">Item</th>
                                            <th style="padding:5px;">Quantity</th>
                                            <th style="padding:5px;">Unit Cost</th>
                                            <th style="padding:5px; text-align: right;">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr style="border:1px solid #ccc;">
                                            <td style="padding:5px;">1</td>
                                            <td style="padding:5px;">
                                                <span style="font-weight:bold">Project Name</span><br>
                                                PHP
                                            </td>
                                            <td style="padding:5px;">1</td>
                                            <td style="padding:5px;">1000 USD</td>
                                            <td style="padding:5px; text-align: right;">1000 USD</td>
                                        </tr>
                                        <tr style="border:1px solid #ccc;">
                                            <td style="padding:5px;">2</td>
                                            <td style="padding:5px;">
                                                <span style="font-weight:bold">Project Name</span><br>
                                                PHP
                                            </td>
                                            <td style="padding:5px;">1</td>
                                            <td style="padding:5px;">1000 USD</td>
                                            <td style="padding:5px;  text-align: right;">1000 USD</td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div style="text-align:right; font-size: 13px;">
                                    <p style="margin-bottom: 6px;">Subtotal: 2000 USD</p>
                                    <p style="margin-bottom: 6px;">Tax(0%): 0 USD</p>
                                    <p style="margin-bottom: 6px; font-size: 16px; font-weight: bold;">Total: 2000 USD</p>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <p style="font-size:12px; margin:6px 0;"><span style="font-weight:bold;">Notes: </span><br>
                                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here'</p>
                            </td>
                        </tr>
                    </tbody>     
                </table>
                <div class="my-3 text-end">
                    <button class="btn btn-primary"><i class="far fa-save"></i> Save</button>
                    <a href="#" class="btn btn-outline-primary"><i class="fas fa-print"></i> Print</a>
                    <a href="#" class="btn btn-outline-primary"><i class="fas fa-share"></i> Resend</a>
                </div>
         	</div>
         </div>
         
     </div>
 </div>


<?php include('footer.php'); ?>